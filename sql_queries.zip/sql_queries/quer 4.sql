-- Determine the distribution of orders by hour of the day.

SELECT 
    HOUR(time) AS order_hour,
    COUNT(*) AS total_orders
FROM 
    orders
GROUP BY 
    HOUR(time)
ORDER BY 
    HOUR(time) ASC;