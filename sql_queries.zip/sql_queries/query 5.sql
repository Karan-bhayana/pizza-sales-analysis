-- Group the Orders by date and calculate the average number of pizzas ordered per day

SELECT 
    ROUND(AVG(daily_pizza_count), 2) AS avg_pizzas_per_day
FROM (
   SELECT 
        o.date,
        SUM(od.quantity) AS daily_pizza_count
    FROM 
        orders o
    JOIN order_details od ON o.order_id = od.order_id
    GROUP BY 
        o.date
) AS daily_summary;