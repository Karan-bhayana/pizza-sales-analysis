-- Analyze the cumulative revenue generated over time (daily/monthly).  
SELECT 
    date,
    ROUND(revenue, 2) AS daily_revenue,
    ROUND(SUM(revenue) OVER (ORDER BY date), 2) AS cumulative_revenue
FROM (
    SELECT 
        orders.date,
        SUM(order_details.quantity * pizzas.price) AS revenue
    FROM 
        order_details
    JOIN 
        pizzas ON order_details.pizza_id = pizzas.pizza_id
    JOIN 
        orders ON orders.order_id = order_details.order_id
    GROUP BY 
        orders.date
) AS sales;