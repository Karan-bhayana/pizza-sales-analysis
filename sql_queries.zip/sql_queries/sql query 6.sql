-- Determine top 3 most ordered pizza types based on revenue and category
WITH PizzaRevenue AS (SELECT pt.category,
        pt.name AS pizza_type,
        SUM(od.quantity * p.price) AS revenue
    FROM  order_details od
    JOIN pizzas p ON od.pizza_id = p.pizza_id
    JOIN pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
    GROUP BY pt.category, pt.name
),
RankedPizzas AS (
    SELECT 
        category,
        pizza_type,
        revenue,
        RANK() OVER (PARTITION BY category ORDER BY revenue DESC) AS rnk
    FROM 
        PizzaRevenue
)
SELECT 
    category,
    pizza_type,
    revenue
FROM 
    RankedPizzas
WHERE 
    rnk <= 3
ORDER BY 
    category, revenue DESC;